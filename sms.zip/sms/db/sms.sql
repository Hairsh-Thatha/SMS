CREATE TYPE gender_enum AS ENUM('M','F');

CREATE TYPE blood_type_enum AS ENUM('AB+','AB-','A+','A-','B+','B-','O+','O-','Bombay');

CREATE TYPE category_enum AS ENUM('General','SC','ST','OBC','EWS');

CREATE TYPE person_with_disability_enum AS ENUM('yes','no');

CREATE TABLE student(
	student_id SERIAL,
	first_name VARCHAR(32) NOT NULL,
	last_name VARCHAR(32),
	dob DATE NOT NULL,
	gender gender_enum NOT NULL,
	blood_type blood_type_enum NOT NULL,
	email_id VARCHAR(256),
	phone_number VARCHAR(16) NOT NULL,
	father_name VARCHAR(64) NOT NULL,
	mother_name VARCHAR(64),
	parents_phone_number VARCHAR(16),
	category category_enum NOT NULL,
	person_with_disability person_with_disability_enum,
	previous_study VARCHAR(32) NOT NULL,
	nationality VARCHAR(32) NOT NULL,
	identity_number VARCHAR(16) NOT NULL,
	identity_type VARCHAR(32) NOT NULL,
	joining_date DATE DEFAULT CURRENT_DATE,
	passing_date DATE,
	created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
	updated_at TIMESTAMP DEFAULT NOW(),
	CONSTRAINT PK_student PRIMARY KEY(student_id),
	CONSTRAINT DF_student_pwd DEFAULT 'NO' for pwd
);
 

CREATE TYPE address_type_enum AS ENUM ('TEMPORARY','PERMANENT');


CREATE TABLE address(
	address_id SERIAL,
	student_id INTEGER,
	address_line1 VARCHAR(64) NOT NULL,
	address_line2 VARCHAR(64),
	city VARCHAR(90) NOT NULL,
	state VARCHAR(64) NOT NULL,
	country VARCHAR(64) NOT NULL,
	postal_code VARCHAR(10) NOT NULL,
	address_type address_type_enum NOT NULL,
	CONSTRAINT PK_address PRIMARY KEY(address_id),
	CONSTRAINT FK_address_student FOREIGN KEY(student_id) REFERENCES student(student_id),
)

