package com.infinira.sms.test;

import com.infinira.sms.model.Student;
import com.infinira.sms.util.RestApi;

import java.util.List;
import java.sql.Date;

import java.text.MessageFormat;

import org.junit.jupiter.api.Test;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.type.TypeFactory;

public class SmsApiTest {
	
	public static int testCreateStudent(Student student) {
        RestApi.validate("student", student);
        int studentId ;
        String restUrl = ACCESS_URL+CREATE_URL;
        String studentJson = RestApi.convertPojoToJson(student);
        String res = RestApi.post(restUrl, POST, studentJson);
        try {
            studentId = Integer.parseInt(res);
        } catch (Throwable th) {
            throw new RuntimeException(SMS_0001, th);
        }
        return studentId;
    }
	
	public static String testGetStudentById(int studentId) {
        if (studentId < 1) {
            throw new RuntimeException(MessageFormat.format(SMS_0005, studentId));
        }
        String restUrl = ACCESS_URL+GET_URL+studentId;
        String response = RestApi.get(restUrl, GET);
        Student student = RestApi.convertJsonToPojo(response, Student.class);
        return MessageFormat.format(SMS_0006, studentId, response);
    }
	
	public static int testUpdateStudent(Student student) {
		RestApi.validate("student", student);
		int status;
        String restUrl = ACCESS_URL+UPDATE_URL;
        String studentJson = RestApi.convertPojoToJson(student);
        String res = RestApi.post(restUrl,PUT, studentJson);
        try {
            status = Integer.parseInt(res);
        } catch (Throwable th) {
            throw new RuntimeException(MessageFormat.format(SMS_0002,student.getStudentId()), th);
        }

        if (status == 1) {
            return status;
        } else {
            throw new RuntimeException(MessageFormat.format(SMS_0004, student.getStudentId()));
        }
    }
	
	public static String testGetAllStudents() {
        String restUrl = ACCESS_URL + GET_ALL_URL;
        String res = RestApi.get(restUrl, GET);
        ObjectMapper mapper = new ObjectMapper();
        List<Student> list = null;
        try {
            list = mapper.readValue(res,TypeFactory.defaultInstance().constructCollectionType(List.class, Student.class));
        } catch (Throwable th) {
            throw new RuntimeException(SMS_0007, th);
        }
        return res;
    }
	
	public static int testDeleteStudentById(int studentId) {
        if (studentId < 1) {
            throw new RuntimeException(MessageFormat.format(SMS_0005, studentId));
        }
        int status;
        String restUrl = ACCESS_URL +DELETE_URL+studentId;
        String res = RestApi.get(restUrl, DELETE);
        try {
            status = Integer.parseInt(res);
        } catch (Throwable th) {
            throw new RuntimeException(SMS_0009, th);
        }
        if (status == 1) {
            return status;
        } else {
          throw new RuntimeException(MessageFormat.format(SMS_0010, studentId));
        }
    }
	
	private static final String POST = "POST";
    private static final String GET = "GET";
	private static final String PUT = "PUT";
	private static final String DELETE = "DELETE";
	private static final String ACCESS_URL = "http://localhost:8080";
	private static final String UPDATE_URL = "/sms/updatestudent";
	private static final String CREATE_URL = "/sms/createstudent";
	private static final String GET_URL = "/sms/getstudentbyid/";
	private static final String GET_ALL_URL = "/sms/getallstudents";
	private static final String DELETE_URL = "/sms/deletestudentbyid/";
	private static final String SMS_0001 = "Failed to get Student id from response";
	private static final String SMS_0002 = "Failed to update the Student with id: {0} ";
	private static final String SMS_0003 = "update for student id {0} is successful";
	private static final String SMS_0004 = "update for student id {0} is Unsuccessful";
	private static final String SMS_0005 = "Invalid Student id : {0}";
	private static final String SMS_0006 = "Get student with StudentId :{0} \nStudent Info {1} :";
	private static final String SMS_0007 = "Exception while converting JSON String to POJO";
	private static final String SMS_0008 = "Get all Alert Info :";
	private static final String SMS_0009 = "Failed to get delete response for Student id :{0}";
	private static final String SMS_0010 = "Delete operation for student id {0} is Unsuccessful";
	
}	