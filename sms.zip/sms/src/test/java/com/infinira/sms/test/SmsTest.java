package com.infinira.sms.test;

import com.infinira.sms.model.Student;

import java.util.List;
import java.sql.Date;

import java.text.MessageFormat;

public class SmsTest {
	
	public static void create(){
		Student student = new Student("HAREESH ","THATHA",  "2489362895098", "UID", "123456789012345");
		student.setDob(Date.valueOf("2022-5-11"));
		student.setGender("Male");
		student.setBloodGroup("a+");
		student.setEmailId("thathaharish12@gmail.com");
		student.setFatherName("Venkata Ramaiah");
		student.setMotherName("Rajeswari");
		student.setParentPhoneNumber("813191980");
		student.setSocialCategory("sc");
		student.setPersonWithDisability("yes");
		student.setPreviousStudy("Intermediate");
		student.setNationality("INDIAN");
		student.setJoiningDate(Date.valueOf("2019-5-1"));
		student.setPassedOutDate(Date.valueOf("2023-5-1"));	
		System.out.println("Created new student with Student id: "+SmsApiTest.testCreateStudent(student));
	}
	
	public static void update(){
		Student student = new Student("HAREESH ","Thatha",  "+91123412    ", "UID", "123456789012345");
		student.setStudentId(58);
		student.setDob(Date.valueOf("2022-5-11"));
		student.setGender("Male");
		student.setBloodGroup("a+");
		student.setEmailId("thathaharish12@gmail.com");
		student.setFatherName("Venkata Ramaiah");
		student.setMotherName("Rajeswari");
		student.setParentPhoneNumber("813191980");
		student.setSocialCategory("sc");
		student.setPersonWithDisability("yes");
		student.setPreviousStudy("Intermediate");
		student.setNationality("INDIAN");
		student.setJoiningDate(Date.valueOf("2019-5-1"));
		student.setPassedOutDate(Date.valueOf("2023-5-1"));
		int status = SmsApiTest.testUpdateStudent(student);
		System.out.println(MessageFormat.format("\nUpdated student succesfully with student id :{0}", student.getStudentId()) );
	}
	
	public static void retrieve(){
		System.out.println("\n"+SmsApiTest.testGetStudentById(8));
	}	
	
	public static void retrieveAll() {
		System.out.println("\nGet all Students info:"+SmsApiTest.testGetAllStudents());
	}
	
	public static void delete() {
		int studentId = 28;
		int status1 = SmsApiTest.testDeleteStudentById(studentId);
		System.out.println(MessageFormat.format("\nDeleted Student with Student Id {0} is Successful", studentId));
	}
	
	public static void main(String args[]){
		create();
		retrieve();
		update();
		delete();
		retrieveAll();
	}
}
	