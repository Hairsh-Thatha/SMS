package com.infinira.sms.util;

import java.text.MessageFormat;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.OutputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

import com.fasterxml.jackson.databind.ObjectMapper;

public class RestApi {
	
	public static String get(String restUrl, String request) {
        validate(REST_URL, restUrl);
        HttpURLConnection conn = null;
        String output = null;
        try {
            URL url = new URL(restUrl);
            conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod(request);
            conn.setRequestProperty(ACCEPT, APPLICATION_JSON);
            if (conn.getResponseCode() == 200 ) {
                BufferedReader br = new BufferedReader(new InputStreamReader((conn.getInputStream())));
                output = br.readLine();
            } else {
                throw new RuntimeException(MessageFormat.format(SMS_0001,conn.getResponseCode()));
            }
        } catch (MalformedURLException ex) {
            throw new RuntimeException(MessageFormat.format(SMS_0002, restUrl));
        } catch (Throwable th) {
            throw new RuntimeException(MessageFormat.format(SMS_0003, restUrl));
        } finally {
            if (conn != null) {
                try {
                    conn.disconnect();
                } catch (Throwable th) {
                }
            }
        }
        return output;
    }
	
	public static String post(String restUrl, String request, String jsonData) {
        validate(REST_URL, restUrl);
        validate(JSON_DATA, jsonData);
        URL obj = null;
        HttpURLConnection conn = null;
        OutputStream os = null;
        try {
            obj = new URL(restUrl);
            conn = (HttpURLConnection) obj.openConnection();
            conn.setRequestMethod(request);
            conn.setRequestProperty(CONTENT_TYPE, APPLICATION_JSON);
            conn.setDoOutput(true);
            os = conn.getOutputStream();
			os.write(jsonData.getBytes());
			os.flush();
        } catch (Throwable th) {
            throw new RuntimeException(SMS_0004, th);
        } finally {
            if (os != null) {
                try {
                    os.close();
                } catch (Throwable th) {
                }
            }
        }
        StringBuilder response = null;
        BufferedReader br = null;
        try {
            if (conn.getResponseCode() == 200 ) {
                br = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                response = new StringBuilder();
                String output;
                while ((output = br.readLine()) != null) {
                    response.append(output);
                }
            } else {
                throw new RuntimeException(MessageFormat.format(SMS_0005, conn.getResponseCode()));
            }
            return response.toString();
        } catch (Throwable th) {
            throw new RuntimeException(SMS_0006, th);
        } finally {
            if (br != null) {
                try {
                    br.close();
                } catch (Throwable th) {
                }
            }
            if (conn != null) {
                try {
                    conn.disconnect();
                } catch (Throwable th) {
                }
            }
        }
    }
	
	public static boolean validate(String name, Object value){
			if (name == null || name.isBlank()) {
				throw new RuntimeException(MessageFormat.format(VALIDATE_NAME,"name", value));
			}
			String str = value.toString();
			if (str == null || str.isBlank()) {
				throw new RuntimeException(MessageFormat.format(VALIDATE_VALUE,name));
			}
			return true;
	}
	
	public static String convertPojoToJson(Object obj) {
        validate("obj", obj);
        ObjectMapper mapper = new ObjectMapper();
        try {
            return mapper.writeValueAsString(obj);
        } catch (Throwable th) {
            throw new RuntimeException(SMS_0007, th);
        }
    }

    public static <T> T convertJsonToPojo(String json, Class<T> valueType) {
        ObjectMapper mapper = new ObjectMapper();
        try {
            return mapper.readValue(json, valueType);
        } catch (Throwable th) {
            throw new RuntimeException(SMS_0008, th);
        }
    }
	
    private static final String CONTENT_TYPE = "Content-Type";
    private static final String APPLICATION_JSON = "application/json";
    private static final String ACCEPT = "Accept";
	private static final String REST_URL = "restUrl";
	private static final String JSON_DATA = "JsonData";
	private static final String VALIDATE_NAME = "{0} cannot be null or empty for value: {1} ";
	private static final String VALIDATE_VALUE = "Null or Empty values cannot be specified for : {0}";
	private static final String SMS_0001 = "Failed : HTTP error code :  {0}";
	private static final String SMS_0002 = "Failed to get the response with malformed URL: {0}";
	private static final String SMS_0003 = "Failed get the response for {0}" ;
	private static final String SMS_0004 = "Failed to post the request.";
	private static final String SMS_0005 = "Failed to post the request: {0}" ;
	private static final String SMS_0006 = "Failed to get the response. ";
	private static final String SMS_0007 = "Failed to convert from JAVA pojo to JSON: ";
	private static final String SMS_0008 = "Failed to convert JSON to JAVA pojo ";

}