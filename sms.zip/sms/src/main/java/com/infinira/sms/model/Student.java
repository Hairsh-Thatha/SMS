package com.infinira.sms.model;

import java.sql.Date;
import java.sql.Timestamp;
import java.time.LocalDate;
import java.text.MessageFormat;
import com.infinira.sms.enums.BloodGroup;
import com.infinira.sms.enums.SocialCategory;
import com.infinira.sms.enums.Gender;
import com.infinira.sms.enums.PersonWithDisability;

public class Student {
	
	private int studentId;
	private String firstName;
	private String lastName;
	private Date dob;
	private Gender gender;
	private BloodGroup bloodGroup;
	private String emailId;
	private String phoneNumber;
	private String fatherName;
	private String motherName;
	private String parentPhoneNumber;
	private SocialCategory socialCategory;
	private PersonWithDisability personWithDisability;
	private String previousStudy;
	private String nationality;
	private String identityNumber;
	private String identityType;
	private Date joiningDate;
	private Date passedOutDate;
	private Timestamp createdDate;
	private Timestamp updatedDate;
	
	public Student() {
		
	}
	public Student(String firstName, String lastName,String phoneNumber, String identityType, String identityNumber ) {
		validate(firstName, FIRST_NAME,  MIN_NAME_SIZE, MAX_NAME_SIZE);
		this.firstName = firstName;
		
		validate(lastName, LAST_NAME,MIN_NAME_SIZE, MAX_NAME_SIZE);
		this.lastName = lastName;
		
		validate(phoneNumber, PHONE_NUMBER, MIN_PHONE_NUMBER_SIZE, MAX_PHONE_NUMBER_SIZE);
		this.phoneNumber = phoneNumber;
		
		validate(identityNumber,IDENTITY_NUMBER, MIN_IDENTITY_NUMBER_SIZE, MAX_IDENTITY_NUMBER_SIZE );
		this.identityNumber = identityNumber;
		
		validate(identityType, IDENTITY_TYPE, MIN_IDENTITY_TYPE_SIZE, MAX_IDENTITY_TYPE_SIZE);
		this.identityType = identityType;
		
	}
	
	public void setStudentId(int studentId) {
		this.studentId = studentId;
	}
	
	public int getStudentId() {
		return studentId;
	}
	
	public void setFirstName(String firstName) {
		validate(firstName, FIRST_NAME,  MIN_NAME_SIZE, MAX_NAME_SIZE);
		this.firstName = firstName;
	}
	
	public String getFirstName() {
		return firstName;
	}
	
	public void setLastName(String lastName) {
		validate(lastName, LAST_NAME,MIN_NAME_SIZE, MAX_NAME_SIZE);
		this.lastName = lastName;
	}
	
	public String getLastName() {
		return lastName;
	}
	
	public void setDob(Date dob) {
		validate(dob, Date.valueOf(LocalDate.now()), DOB);
		this.dob = dob;
	}
	
	public Date getDob() {
		return dob;
	}
	
	public void setGender(String gender) {
		this.gender = Gender.getGender(gender, VALIDATE_ENUM, GENDER);
	}
	
	public Gender getGender() {
		return gender;
	}
		
	public void setBloodGroup(String bloodGroup) {
		this.bloodGroup  = BloodGroup.getBloodGroup(bloodGroup, VALIDATE_ENUM, BLOOD_GROUP);	
	}

	public BloodGroup getBloodGroup() {
		return bloodGroup;
	}
	
	public void setEmailId(String emailId) {
		validate(emailId,  EMAIL_ID, MIN_EMAIL_ID_SIZE, MAX_EMAIL_ID_SIZE);
		this.emailId = emailId;
	}
	
	public String getEmailId(){
		return emailId;
	}
	
	public void setPhoneNumber(String phoneNumber) {
		validate(phoneNumber, PHONE_NUMBER, MIN_PHONE_NUMBER_SIZE, MAX_PHONE_NUMBER_SIZE);
		this.phoneNumber = phoneNumber;
	}
	
	public String getPhoneNumber() {
		return phoneNumber;
	}
	
	public void setFatherName(String fatherName) {
		validate(fatherName, FATHER_NAME, MIN_PARENTS_NAME_SIZE, MAX_PARENTS_NAME_SIZE);
		this.fatherName = fatherName;
	}
	
	public String getFatherName() {
		return fatherName;
	}

	public void setMotherName(String motherName) {
		validate(motherName, MOTHER_NAME, MIN_PARENTS_NAME_SIZE, MAX_PARENTS_NAME_SIZE);
		this.motherName = motherName;
	}	
	
	public String getMotherName() {
		return motherName;
	}
	
	public void setParentPhoneNumber (String parentPhoneNumber) {
		validate(parentPhoneNumber, PARENT_PHONE_NUMBER, MIN_PHONE_NUMBER_SIZE, MAX_PHONE_NUMBER_SIZE);
		this.parentPhoneNumber = parentPhoneNumber;
	}
	
	public String getParentPhoneNumber() {
		return parentPhoneNumber;
	}
	
	public void setSocialCategory(String socialCategory) {
		this.socialCategory = SocialCategory.getSocialCategory(socialCategory, VALIDATE_ENUM, SOCIALCATEGORY);
	}
	
	public SocialCategory getSocialCategory() {
		return socialCategory;
	}
	
	public void setPersonWithDisability(String personWithDisability) {
		this.personWithDisability = PersonWithDisability.getPersonWithDisability(personWithDisability, VALIDATE_ENUM, PWD);
	}
	
	public PersonWithDisability getPersonWithDisability() {
		return personWithDisability;
	}
	
	public void setPreviousStudy(String previousStudy) {
		validate(previousStudy, PREVIOUS_STUDY, MIN_PREVIOUS_STUDY_SIZE, MAX_PREVIOUS_STUDY_SIZE);
		this.previousStudy = previousStudy;
	}

	public String getPreviousStudy() {
		return previousStudy;
	}

	public void setNationality(String nationality) {
		validate(nationality, NATIONALITY, MIN_NATIONALITY_SIZE, MAX_NATIONALITY_SIZE);
		this.nationality = nationality;
	}
	
	public String getNationality() {
		return nationality;
	}
	
	public void setIdentityNumber(String identityNumber) {
		validate(identityNumber, IDENTITY_NUMBER, MIN_IDENTITY_NUMBER_SIZE, MAX_IDENTITY_NUMBER_SIZE);
		this.identityNumber = identityNumber;
	}
	
	public String getIdentityNumber() {
		return identityNumber;
	}
		
	public void setIdentityType(String identityType) {
		validate(identityType, IDENTITY_TYPE, MIN_IDENTITY_TYPE_SIZE, MAX_IDENTITY_TYPE_SIZE);
		this.identityType = identityType;
	}
	
	public String getIdentityType() {
		return identityType;
	}
	
	public void setJoiningDate(Date joiningDate) {
		this.joiningDate = joiningDate;
	}
	
	public Date getJoiningDate() {
		return joiningDate;
	}
	
	public void setPassedOutDate(Date passedOutDate) {
		validate(joiningDate, passedOutDate, PASSED_OUT_DATE);
		this.passedOutDate = passedOutDate;
	}
	
	public Date getPassedOutDate() {
		return passedOutDate;
	}
	
	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}
	
	public Timestamp getCreatedDate() {
		return createdDate;
	}
	
	public void setUpdatedDate(Timestamp updatedDate) {
		validate(updatedDate, createdDate, UPDATED_DATE);
		this.updatedDate = updatedDate;
	}
	
	public Timestamp getUpdatedDate() {
		return updatedDate;
	}
	
	private void validate(Object obj, Object... varargs) {
		if (obj instanceof String){
			String str = (String)obj;
			if (str == null || str.isBlank()) {
				throw new RuntimeException(MessageFormat.format(VALIDATE_VALUE, varargs[0]));
			}
			
			if (str.trim().length() < (int)varargs[1]) {
				throw new RuntimeException(MessageFormat.format(VALIDATE_MIN_SIZE, varargs[0], varargs[1]));
			} else if (str.trim().length() > (int)varargs[2]) {
				throw new RuntimeException(MessageFormat.format(VALIDATE_MAX_SIZE, varargs[0], varargs[2]));
			}
			
		} else if (obj instanceof Date) {
			Date startDate = (Date)obj;
			if (varargs[0] !=  null && (startDate.toLocalDate().isAfter(((Date)varargs[0]).toLocalDate()) || startDate.toLocalDate().isEqual(((Date)varargs[0]).toLocalDate()))){
				throw new RuntimeException(MessageFormat.format(VALIDATE_DATE, varargs[1]));
			}
		} else if(obj instanceof Timestamp) {
			if(((Timestamp)obj).before((Timestamp)varargs[0])){
				throw new RuntimeException(MessageFormat.format(VALIDATE_DATE, varargs[1]));
			}
		}
	}
		
	private static final int MIN_NAME_SIZE = 1;
	private static final int MAX_NAME_SIZE = 32;
	private static final int MIN_EMAIL_ID_SIZE = 10;
	private static final int MAX_EMAIL_ID_SIZE = 256;
	private static final int MIN_PHONE_NUMBER_SIZE = 5;
	private static final int MAX_PHONE_NUMBER_SIZE = 15;
	private static final int MIN_PARENTS_NAME_SIZE = 1;
	private static final int MAX_PARENTS_NAME_SIZE = 64;
	private static final int MIN_PREVIOUS_STUDY_SIZE = 2;
	private static final int MAX_PREVIOUS_STUDY_SIZE = 32;
	private static final int MIN_IDENTITY_NUMBER_SIZE = 7;
	private static final int MAX_IDENTITY_NUMBER_SIZE = 16;
	private static final int MIN_IDENTITY_TYPE_SIZE = 2;
	private static final int MAX_IDENTITY_TYPE_SIZE = 16;
	private static final int MIN_NATIONALITY_SIZE = 4;
	private static final int MAX_NATIONALITY_SIZE = 35;
	private static final String VALIDATE_VALUE = "{0} cannot be null or empty.";
	private static final String VALIDATE_MIN_SIZE = "Invalid {0} size. Size must be more than {1} characters.";
	private static final String VALIDATE_MAX_SIZE = "Invalid {0} size. Size must be less than {1} characters.";
	private static final String VALIDATE_DATE = "Invalid {0}.";
	private static final String VALIDATE_ENUM = "Invalid {0} : {1}.";
	private static final String VALIDATE_PERCENTAGE = "Invalid value for {0}. {0} must be greater than {1} : {2}"; 
	private static final String FIRST_NAME = "First name";
	private static final String LAST_NAME = "Last_name";
	private static final String GENDER = "Gender";
	private static final String DOB = "DOB";
	private static final String PASSED_OUT_DATE = "Passed out date";
	private static final String BLOOD_GROUP = "Blood group";
	private static final String EMAIL_ID = "Email id";
	private static final String FATHER_NAME = "Father name";
	private static final String MOTHER_NAME = "Mother name";
	private static final String PHONE_NUMBER = "Phone number";
	private static final String PARENT_PHONE_NUMBER = "Parent phone number";
	private static final String SOCIALCATEGORY = "SocialCategory";
	private static final String PWD = "person with disability";
	private static final String PREVIOUS_STUDY = "Previous Study";
	private static final String NATIONALITY = "Nationality";
	private static final String IDENTITY_NUMBER = "Identity number";
	private static final String IDENTITY_TYPE = "Identity type";
	private static final String UPDATED_DATE = "Updated date";
	
}




 

 