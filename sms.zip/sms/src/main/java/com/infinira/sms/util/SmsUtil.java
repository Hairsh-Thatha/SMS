package com.infinira.sms.util;

import java.text.MessageFormat;

public class SmsUtil {
	
	public static SmsException throwEx(String msg, Throwable th,Object... varargs ){
		String message = ResourceUtil.getInstance().getString(msg, varargs);
		return new SmsException(message, th);	
	}	
}

