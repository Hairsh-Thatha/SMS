package com.infinira.sms.controller;

import com.infinira.sms.service.ISmsService;
import com.infinira.sms.model.Student;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.ui.Model;
import org.springframework.beans.factory.annotation.Autowired;

@RestController
@RequestMapping(value="/sms")
public class SmsController {
	
	@Autowired
	private ISmsService iSmsService;
	
	@GetMapping("/getallstudents")
	public ResponseEntity <List<Student>> getAllStudents(){
		return new ResponseEntity <List<Student>> (iSmsService.getAllStudents(), HttpStatus.OK);
	}
	
	@PostMapping("/createstudent")
	public ResponseEntity <Integer> createStudent(@RequestBody Student student){
		return new ResponseEntity <Integer>((Integer)iSmsService.createStudent(student), HttpStatus.OK);
	}

	@GetMapping("/getstudentbyid/{id}")
	public ResponseEntity <Student> getStudentById(@PathVariable("id") int id){
		return new ResponseEntity <Student> (iSmsService.getStudentById(id), HttpStatus.OK);	
	}
	
	@PutMapping("/updatestudent")
	public ResponseEntity <Integer> updateStudent(@RequestBody Student student){
		return new ResponseEntity <Integer> (iSmsService.updateStudent(student), HttpStatus.OK);
	}

	@DeleteMapping("/deletestudentbyid/{id}")
	public ResponseEntity <Integer> deleteStudent(@PathVariable("id") int id){
		return new ResponseEntity <Integer> (iSmsService.deleteStudentById(id), HttpStatus.OK);
	}	
}