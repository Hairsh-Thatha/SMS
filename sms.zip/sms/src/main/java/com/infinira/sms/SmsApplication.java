package com.infinira.sms;

import java.util.Collections;

import org.springframework.context.annotation.Configuration;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;
import springfox.documentation.builders.PathSelectors;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.service.Contact;

@SpringBootApplication
@Configuration
@EnableSwagger2
public class SmsApplication implements WebMvcConfigurer {

	public static void main(String[] args) {
        SpringApplication.run(SmsApplication.class, args);
    }
	
	@Bean
    public Docket productApi() {
       return new Docket(DocumentationType.SWAGGER_2)
				.apiInfo(apiInfo())
				.select()
                .apis(RequestHandlerSelectors.basePackage("com.infinira.sms.controller"))
                .paths(PathSelectors.any())
                .build();
    }
	
	 private ApiInfo apiInfo() {
        return new ApiInfo("SMS REST APIs",
                "REST APIs for SMS Application",
                "1.0",
                "Terms of service",
                new Contact("Harish", "www.javaguides.net", "thathaharish12@gmail.com"),
                "License of API",
                "API license URL",
                Collections.emptyList());
    }
}
