package com.infinira.sms.enums;

import java.text.MessageFormat;

public enum Gender {
	MALE("M"),
	FEMALE("F"),
	OTHERS("O");
	
	private final String genderType;
	
	Gender(String genderType) {
		this.genderType = genderType;
	}
	
	public String getGenderType() {
		return genderType;
	}
			
	public static Gender getGender(String gender, String msg, String name) {
		if (gender == null || gender.isBlank()) {
			throw new RuntimeException(MessageFormat.format(VALIDATE_VALUE, name));
		}
		gender = gender.trim();
		for(Gender genderEnum : Gender.values()) {
            if(genderEnum.name().equalsIgnoreCase(gender) || genderEnum.getGenderType().equalsIgnoreCase(gender)) {
                return genderEnum;
            }
        }
		throw new RuntimeException(MessageFormat.format( msg, name, gender));
	}
	private static final String VALIDATE_VALUE = "{0} cannot be null or empty.";
}


  
  
  
  
  
  
  