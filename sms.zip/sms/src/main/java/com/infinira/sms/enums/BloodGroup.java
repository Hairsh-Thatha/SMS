package com.infinira.sms.enums;

import java.text.MessageFormat;

public enum BloodGroup {
	AB_POSITIVE("AB+"),
	AB_NEGATIVE("AB-"),
	A_POSITIVE("A+"),
	A_NEGATIVE("A-"),
	B_POSITIVE("B+"),
	B_NEGATIVE("B-"),
	O_POSITIVE("O+"),
	O_NEGATIVE("O-"),
	BOMBAY("BOMBAY");
	
	private final String bloodGroupName;
	
	BloodGroup(String bloodGroupName) {
		this.bloodGroupName = bloodGroupName;
	}
	
	public String getBloodGroupName() {
		return bloodGroupName;
	}
	
	public static BloodGroup getBloodGroup(String bloodGroup, String msg, String name) {
		if (bloodGroup == null || bloodGroup.isBlank()) {
			throw new RuntimeException(MessageFormat.format(VALIDATE_VALUE, name));
		}
		bloodGroup = bloodGroup.trim();
		for(BloodGroup blood : BloodGroup.values()) {
            if(blood.name().equalsIgnoreCase(bloodGroup) || blood.getBloodGroupName().equalsIgnoreCase(bloodGroup)) {
                return blood;
            }
        }
		throw new RuntimeException(MessageFormat.format(msg, name, bloodGroup));
	}
	private static final String VALIDATE_VALUE = "{0} cannot be null or empty.";
}


