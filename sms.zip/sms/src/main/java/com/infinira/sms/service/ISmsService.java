package com.infinira.sms.service;

import com.infinira.sms.model.Student;
import java.util.List;
import java.util.ArrayList;

public interface ISmsService {
	public int createStudent(Student student);
	public List <Student> getAllStudents();
	public Student getStudentById (int studentId);
	public int deleteStudentById(int studentId);
	public int updateStudent(Student student);
}