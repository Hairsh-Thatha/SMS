package com.infinira.sms.util;

import java.util.ResourceBundle;
import java.util.Locale;
import java.text.MessageFormat;
import java.text.NumberFormat;  

public class ResourceUtil {
	private static volatile ResourceUtil resourceUtil = null;
	private static final String PROPERTY_FILE = "sms_messages";
	private static ResourceBundle resourceBundle = null;
	
	public static ResourceUtil getInstance() {
		if( resourceUtil == null) {
			synchronized (ResourceUtil.class) {
				if ( resourceUtil == null) {
					resourceUtil = new ResourceUtil();
				}
			}
		}
		return resourceUtil;
	}
	
	private ResourceUtil(){
		this.resourceBundle = getResourceBundle(PROPERTY_FILE, Locale.getDefault());
	}	

	private static ResourceBundle getResourceBundle(String resourceFile, Locale locale){
		if(locale == null){
			locale = Locale.getDefault();
		}
		if (resourceFile == null || resourceFile.trim().isEmpty()){
			throw new RuntimeException(MSG_001, null);
		}
		try{
			resourceBundle = ResourceBundle.getBundle(resourceFile, locale);
		}catch (Throwable th){
			throw new RuntimeException(MessageFormat.format(MSG_002, resourceFile), th);
		}
		return resourceBundle;
	}
	
	public static String getString(String key, Object... varargs) {
		if(key == null || key.trim().isEmpty()){
			return MSG_003;
		}
		
		if(!resourceBundle.containsKey(key)){
			return MessageFormat.format(MSG_004, key);
		}	
		
		String message = null;
		try{
			message = resourceBundle.getString(key);
		} catch(Throwable th){
			return MessageFormat.format(MSG_005, key);
		}
		
		if(message == null || message.trim().isEmpty()){
			return MessageFormat.format(MSG_007, key);
		}
		return MessageFormat.format(message, varargs);
    }
		
	private static final String MSG_001 = "Property file cannot be null or empty.";
	private static final String MSG_002  ="Property file not found : {0}";
	private static final String MSG_003 = "Key cannot be null or empty.";
	private static final String MSG_004 = "<{0}> key is not present in the property file.";
	private static final String MSG_005 = "Failed to retrieve message. object found for the given key <{0}> is not a string.";
	private static final String MSG_006 = "Locale constructor value cannot be null or empty. We need to pass the values to it.";
	private static final String MSG_007 = "Message of the key <{0}> cannot be null or empty.";
}




