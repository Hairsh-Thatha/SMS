package com.infinira.sms.util;

public class SmsException extends RuntimeException {
	public SmsException(String str){
		super(str);		
	}
	public SmsException(String str,Throwable th){
		super(str, th);		
	}
}

