package com.infinira.sms.enums;

import java.text.MessageFormat;

public enum SocialCategory {
	GENERAL("General"),
	SC("SC"),
	ST("ST"),
	OBC("OBC"),
	EWS("EWS");
	
	private final String categoryName;
	
	SocialCategory(String categoryName) {
		this.categoryName = categoryName;
	}
	
	public String getCategoryName() {
		return categoryName;
	}
	
	public static SocialCategory getSocialCategory(String category, String msg, String name) {
		if (category == null || category.isBlank()) {
			throw new RuntimeException(MessageFormat.format(VALIDATE_VALUE, name));
		}
		category = category.trim();
		for(SocialCategory categoryEnum : SocialCategory.values()) {
            if(categoryEnum.name().equalsIgnoreCase(category)) {
                return categoryEnum;
            }
        }
		throw new RuntimeException(MessageFormat.format( msg, name, category));
	}
	private static final String VALIDATE_VALUE = "{0} cannot be null or empty.";
}