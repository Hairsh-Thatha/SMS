package com.infinira.sms.util;

import java.io.InputStream;
import java.text.MessageFormat;
import java.util.Properties;
import java.sql.DriverManager;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class DBUtil {
	
	private static volatile DBUtil dbUtil = null;
	private static String url;
	private static String username;
	private static String password;
	
	public static DBUtil getInstance() {
		if( dbUtil == null) {
			synchronized (DBUtil.class) {
				if ( dbUtil == null) {
					dbUtil = new DBUtil();
				}
			}
		}
		return dbUtil;
	}
	
	private DBUtil() {
		init();
	}
	
	public void init(){
		InputStream inputStream = null;
		Properties properties = new Properties();
		try {	
			inputStream = this.getClass().getClassLoader().getResourceAsStream(PROPERTY_FILE);
		} catch(Throwable th){
			throw new RuntimeException(MessageFormat.format(MSG_002, PROPERTY_FILE), th);
		} 
		
		try {
			properties.load(inputStream);
		} catch(Throwable th) {
			throw new RuntimeException(MessageFormat.format(MSG_003, PROPERTY_FILE), th);
		} finally { 
			if (inputStream != null) {
				try{
					inputStream.close();
				} catch(Throwable th) {
					//throw new RuntimeException(MSG_004, th);
				}
			}
		}
		url = properties.getProperty(URL);
		validate(url, URL);
		username = properties.getProperty(USERNAME);
		validate(username, USERNAME);
		password = properties.getProperty(PASSWORD);
		validate(password, PASSWORD);
		
	}
		
	public Connection getConnection() {
		try {
			return DriverManager.getConnection( url, username, password);
		} catch(Throwable th){
			throw new RuntimeException(MessageFormat.format(MSG_001, url, username), th);
		}
	}
	
	public static void closeConnection( Connection connection, ResultSet rs, PreparedStatement ps ) {
		if (rs != null) {
			try {
				rs.close();
			} catch (Throwable th) {
				//throw new RuntimeException(MSG_007, th);
			}
		}
		
		if (ps != null) {
			try {
				ps.close();
			} catch (Throwable th) {
				//throw new RuntimeException(MSG_008, th);
			}
		}
		
		if (connection != null) {
			try {
				connection.close();
			} catch (Throwable th) {
				//throw new RuntimeException(MSG_006, th);
			}
		}
	}

	private void validate(String value, String name) {		
	//Validating whether the property value is empty or NULL
		if (value == null || (value.trim().isEmpty())) { 
			throw new RuntimeException(MessageFormat.format(MSG_005, name));
		}
	}

	private static final String PROPERTY_FILE = "db.properties";
	private static final String URL = "db.url";
	private static final String USERNAME = "db.username";
	private static final String PASSWORD = "db.password";
	private static final String MSG_001 = "Failed to establish the connection for the url {0} to the user : {1}";
	private static final String MSG_002 = "Could not find the properties file : {0}";
	private static final String MSG_003 = "Could not read the properties file : {0}";
	private static final String MSG_004 = "Failed to close the inputStream.";
	private static final String MSG_005 = "{0} cannot be null or empty.";
	private static final String MSG_006 = "Failed to close the connection.";
	private static final String MSG_007 = "Failed to close the ResultSet.";
	private static final String MSG_008 = "Failed to close the PreparedStatement.";
}
