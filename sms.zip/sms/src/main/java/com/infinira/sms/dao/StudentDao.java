package com.infinira.sms.dao;

import com.infinira.sms.model.Student;
import com.infinira.sms.util.DBUtil;
import com.infinira.sms.util.SmsUtil;
import com.infinira.sms.util.SmsException;
import java.util.List;
import java.util.ArrayList;
import java.util.Properties;
import java.sql.Types;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Level;
import org.apache.logging.log4j.core.config.Configurator;

public class StudentDao {
	private static final Logger logger = LogManager.getLogger("com.infinira.sms.dao.StudentDao.class");

	public static int createStudent(Student student) {
		if (student == null){
			throw SmsUtil.throwEx("SMS_0012",null);
		}
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		int studentId = 0;
		try {
			conn = DBUtil.getInstance().getConnection();
			pstmt = conn.prepareStatement(INSERT_QUERY, new String[] {STUDENT_ID});
			int index = setPrepareStatementData(pstmt, student);
			pstmt.executeUpdate();
			rs = pstmt.getGeneratedKeys();
			if( rs != null && rs.next()){
				studentId = rs.getInt(STUDENT_ID);
			} else{
				throw SmsUtil.throwEx("SMS_0011",null,student.getFirstName(),student.getLastName());
			}
		}catch(SmsException smsEx){
			throw smsEx;
		}catch( Throwable th) {
			throw SmsUtil.throwEx("SMS_0001", th, student.getFirstName());
		} finally {
			DBUtil.closeConnection(conn, rs, pstmt);
		}
		return studentId;
	}

	public static List <Student> getAllStudents() {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		List <Student> list = new ArrayList<Student>();
		try {
			conn = DBUtil.getInstance().getConnection();
			pstmt = conn.prepareStatement(SELECT_QUERY);
			rs = pstmt.executeQuery();
			while(rs.next()) {
				Student student = getStudentData(rs);
				list.add(student);
			}
		} catch (Throwable th) {
			throw SmsUtil.throwEx("SMS_0009", th);
		} finally {
			DBUtil.closeConnection(conn, rs, pstmt);
		}
		if (list.isEmpty()){
			throw SmsUtil.throwEx("SMS_0010", null);
		}
		return list;
	}

	public static Student getStudentById(int studentId){
		if(studentId <= 0){
			throw SmsUtil.throwEx("SMS_0031", null, studentId);
		}
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		Student student = null;
		try {
			conn = DBUtil.getInstance().getConnection();
			pstmt = conn.prepareStatement(SEARCH_QUERY);
			pstmt.setInt(1,studentId);
			rs = pstmt.executeQuery();
			if(rs.next()){
				 student = getStudentData(rs);
				 
			} else {
				throw SmsUtil.throwEx("SMS_0002", null, studentId);
			}
		}catch (SmsException smsEx) {
			throw smsEx;
		}catch (Throwable th) {
			throw SmsUtil.throwEx("SMS_0004", th, studentId);
		} finally {
			DBUtil.closeConnection(conn, rs, pstmt);
		}
		return student;
	}

	public static int deleteStudentById(int studentId){
		if(studentId <= 0){
			throw SmsUtil.throwEx("SMS_0031", null, studentId);
		}
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		int count = 0;
		try {
			conn = DBUtil.getInstance().getConnection();
			pstmt = conn.prepareStatement(DELETE_QUERY);
			pstmt.setInt(1,studentId);
			count = pstmt.executeUpdate();
		} catch (Throwable th) {
			throw SmsUtil.throwEx("SMS_0005", th, studentId);
		} finally {
			DBUtil.closeConnection(conn, rs, pstmt);
		}
		if (count ==0) {
			throw SmsUtil.throwEx("SMS_0008", null, studentId)	;
		}
		return count;
	}

	public static int updateStudent(Student student){
		if (student == null){
			throw SmsUtil.throwEx("SMS_0012", null);
		}
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		int count = 0;
		try {
			conn = DBUtil.getInstance().getConnection();	
			pstmt = conn.prepareStatement(UPDATE_QUERY);
			int index = setPrepareStatementData(pstmt, student);
			pstmt.setInt(index, student.getStudentId());
			count = pstmt.executeUpdate();
		}catch(Throwable th) {
			throw SmsUtil.throwEx("SMS_0003", th, student.getStudentId());
		}finally {
			DBUtil.closeConnection(conn, rs, pstmt);
		}
		return count;
	}
	
	private static Student getStudentData(ResultSet rs){
		try{
			Student student = new Student (rs.getString("first_name"), rs.getString("last_name"), rs.getString("phone_number"),rs.getString("identity_type"), rs.getString("identity_number"));
			student.setDob(rs.getDate("dob"));
			student.setGender((String)rs.getObject("gender"));
			student.setStudentId(rs.getInt(STUDENT_ID));
			student.setLastName(rs.getString("last_name"));
			student.setBloodGroup((String)rs.getObject("blood_type"));
			student.setEmailId(rs.getString("email_id"));
			student.setFatherName(rs.getString("father_name"));
			student.setMotherName(rs.getString("mother_name"));
			student.setParentPhoneNumber(rs.getString("parents_phone_number"));
			student.setSocialCategory((String)rs.getObject("category"));
			student.setPersonWithDisability((String)rs.getObject("person_with_disability"));
			student.setPreviousStudy(rs.getString("previous_study"));
			student.setNationality(rs.getString("nationality"));
			student.setJoiningDate(rs.getDate("joining_date"));
			student.setPassedOutDate(rs.getDate("passing_date"));
			student.setCreatedDate(rs.getTimestamp("created_at"));
			student.setUpdatedDate(rs.getTimestamp("updated_at"));
			return student;
		}catch( Throwable th){
			throw SmsUtil.throwEx("SMS_0006", th);
		}
		
	}

	private static int setPrepareStatementData(PreparedStatement pstmt, Student student) {
		int index = 0;
		try {
			pstmt.setString(++index, student.getFirstName());
			pstmt.setString(++index, student.getLastName());
			pstmt.setString(++index, student.getPhoneNumber());
			pstmt.setString(++index, student.getIdentityNumber());
			pstmt.setString(++index, student.getIdentityType());
			pstmt.setDate(++index, student.getDob());
			pstmt.setObject(++index, student.getGender().getGenderType(), Types.OTHER);
			pstmt.setObject(++index, student.getBloodGroup().getBloodGroupName(), Types.OTHER);
			pstmt.setString(++index, student.getFatherName());
			pstmt.setString(++index, student.getMotherName());
			pstmt.setString(++index, student.getParentPhoneNumber());
			pstmt.setString(++index, student.getEmailId());
			pstmt.setObject(++index, student.getSocialCategory().getCategoryName(), Types.OTHER);
			pstmt.setObject(++index, student.getPersonWithDisability().getPersonWithDisabilityType(), Types.OTHER);
			pstmt.setString(++index, student.getPreviousStudy());
			pstmt.setString(++index, student.getNationality());
			pstmt.setDate(++index, student.getJoiningDate());
			pstmt.setDate(++index, student.getPassedOutDate());
		} catch(Throwable th) {
			throw SmsUtil.throwEx("SMS_0007", th);
		}
		return ++index;
	}
	
	private static final String INSERT_QUERY = """
												Insert into student
													(first_name,last_name,phone_number,identity_number,
													identity_type,dob,gender,blood_type,
													father_name,mother_name,parents_phone_number,
													email_id,category,person_with_disability,
													previous_study,nationality,
													joining_date, passing_date)
												values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?) 
												RETURNING student_id
												""";
	private static final String SELECT_QUERY = """
												Select 
													student_id, first_name, last_name, 
													dob, gender, blood_type, email_id,
													phone_number, father_name, mother_name,
													parents_phone_number, category,
													person_with_disability , previous_study, 
													nationality, identity_number,identity_type,
													joining_date,passing_date,created_at,updated_at
												from Student
												""";
	private static final String SEARCH_QUERY = """
												Select * from Student where student_id =?
												""";
	private static final String DELETE_QUERY = """
												Delete from Student where student_id=?
												""";
	private static final String UPDATE_QUERY = """
												Update Student SET 
													first_name = ?, last_name = ?, phone_number = ?,
													identity_number = ?, identity_type = ?,
													dob = ?, gender = ?,blood_type = ?,
													father_name = ?, mother_name = ?,
													parents_phone_number = ? , email_id = ?, category = ?, 
													person_with_disability = ?, previous_study = ?,
													nationality = ?,joining_date =?, passing_date=? 
												where student_id = ?
												""";
	private static final String STUDENT_ID = "student_id";
	private static final String  PROPERTY_FILE = "log4j2.properties";
}
