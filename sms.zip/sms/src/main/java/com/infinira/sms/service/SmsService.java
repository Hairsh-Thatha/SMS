package com.infinira.sms.service;

import com.infinira.sms.model.Student;
import com.infinira.sms.dao.StudentDao;

import java.util.List;
import java.util.ArrayList;

import org.springframework.stereotype.Service;

@Service
public class SmsService implements ISmsService {
	
	public List<Student> getAllStudents() {
		return StudentDao.getAllStudents();
	}
	
	public int createStudent(Student student) {
		return StudentDao.createStudent(student);
	}
	
	public Student getStudentById(int studentId) {
		return StudentDao.getStudentById(studentId);
	}
	
	public int deleteStudentById(int studentId) {
		return StudentDao.deleteStudentById(studentId);
	}
	
	public int updateStudent(Student student) {
		return StudentDao.updateStudent(student);
	}

}
