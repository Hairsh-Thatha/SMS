package com.infinira.sms.enums;

import java.text.MessageFormat;

public enum PersonWithDisability {
	YES("yes"),
	NO("no");
	
	private final String personWithDisabilityType;
	
	PersonWithDisability(String personWithDisabilityType) {
		this.personWithDisabilityType = personWithDisabilityType;
	}
	
	public String getPersonWithDisabilityType() {
		return personWithDisabilityType;
	}
	
	public static PersonWithDisability getPersonWithDisability(String personWithDisability, String msg, String name) {
		if (personWithDisability == null || personWithDisability.isBlank()) {
			throw new RuntimeException(MessageFormat.format(VALIDATE_VALUE, name));
		}
		personWithDisability = personWithDisability.trim();
		for(PersonWithDisability personWithDisabilityEnum : PersonWithDisability.values()) {
            if(personWithDisabilityEnum.name().equalsIgnoreCase(personWithDisability)) {
                return personWithDisabilityEnum;
            }
        }
		throw new RuntimeException(MessageFormat.format(msg, name, personWithDisability));
	}
	private static final String VALIDATE_VALUE = "{0} cannot be null or empty.";

}